class genral{

       public static void main (String args[]){
           SMS s = new SMS("Hi Shayan , How can I help you?", "31666");
           s.display();
           Email show = new Email ("Hi Shayan , How can I help you?", "AI bot", "Shayan","Assistance");
           show.display();
       
       }
}
class Message {
   String text ;
   Message(String text){
   this.text = text;}
    void display(){
    System.out.println(text);}
}
class SMS extends Message {
String RecipantContactNo ;

SMS(String text , String RecipantContactNo){
super(text);
this.RecipantContactNo = RecipantContactNo;}
void display(){
    System.out.println(super.text);
System.out.println(RecipantContactNo);}
}
 class Email extends Message{
String sender ;
String reciever ; 
String subject ;
Email(String text, String sender, String reciever, String subject){
super(text);
this.sender = sender;
this.reciever = reciever;
this.subject = subject;}
void display (){
System.out.println(super.text);
System.out.println(this.sender);
System.out.println(this.reciever);
System.out.println(this.subject);}}
