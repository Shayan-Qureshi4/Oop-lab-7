class salary{

public static void main(String[] args){

Employee e1= new Employee();
Employee.manager m1 = e1.new manager();
Employee.worker w1 = e1.new worker();

System.out.println("Employee salary "+ e1.calculatesalry());
System.out.println("Manager salary "+m1.calculatesalry());
System.out.println("Worker salary "+w1.calculatesalry());


}


}

public class Employee {
    double salary=5000;
    double calculatesalry(){
     return salary;
    }
   
   class manager extends Employee{
        @Override
   double calculatesalry(){
   return salary  += 15000;
   }
   }
   class worker extends Employee{
        @Override
   double calculatesalry(){
   return salary  += 10000;
   }
   }
   
}

